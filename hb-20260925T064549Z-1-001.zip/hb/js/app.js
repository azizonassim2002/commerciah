/* Navigation, page "Plus", données de démonstration */
(function () {
  var view = document.getElementById('view');
  var tabbar = document.getElementById('tabbar');

  /* icônes statiques du HTML */
  document.querySelectorAll('[data-icon]').forEach(function (el) {
    el.innerHTML = I[el.getAttribute('data-icon')] || '';
  });


  /* ---------- page Plus ---------- */
  function more(root) {
    var s = Store.state;
    root.innerHTML =
      '<h1>Plus</h1><p class="sub">Outils et réglages</p>' +
      '<div class="grid2" style="margin-top:16px">' +
        tile('' + I.box + '', 'Articles', '#/articles') +
        tile('' + I.card + '', 'Paiements', '#/payments') +
        tile('' + I.truck + '', 'Livraisons', '#/deliveries') +
        tile('' + I.file + '', 'Documents', '#/documents') +
      '</div>' +
      '<h2>Données</h2>' +
      '<div class="card">' +
        '<div class="kv"><span class="k">Clients</span><span class="v">' + s.clients.length + '</span></div>' +
        '<div class="kv"><span class="k">Articles</span><span class="v">' + s.articles.length + '</span></div>' +
        '<div class="kv"><span class="k">Commandes</span><span class="v">' + s.orders.length + '</span></div>' +
        '<div class="kv"><span class="k">Paiements</span><span class="v">' + s.payments.length + '</span></div>' +
        '<div class="kv"><span class="k">Documents</span><span class="v">' + s.documents.length + '</span></div>' +
      '</div>' +
      '<div style="height:14px"></div>' +
      '<button class="btn ghost" id="demo">Recharger les données de démonstration</button>' +
      '<div style="height:10px"></div>' +
      '<button class="btn ghost" id="wipe" style="color:var(--red)">Effacer toutes les données</button>' +
      '<p class="small muted" style="text-align:center;margin-top:18px">Commercia • fonctionne hors ligne</p>';

    root.querySelectorAll('[data-go]').forEach(function (b) {
      b.onclick = function () { location.hash = b.getAttribute('data-go'); };
    });
    root.querySelector('#demo').onclick = function () {
      UI.confirm({ title: 'Recharger la démonstration ?', text: 'Toutes les données actuelles seront remplacées.', okLabel: 'Recharger' })
        .then(function (ok) {
          if (!ok) return;
          Store.reset().then(seed).then(function () { UI.toast('Démonstration rechargée ✓'); render(); });
        });
    };
    root.querySelector('#wipe').onclick = function () {
      UI.confirm({ title: 'Effacer toutes les données ?', text: 'Cette action est irréversible.' })
        .then(function (ok) {
          if (!ok) return;
          Store.reset().then(function () { UI.toast('Données effacées ✓'); render(); });
        });
    };
  }

  function tile(ic, nm, go) {
    return '<button class="tile" data-go="' + go + '"><span class="ic">' + ic + '</span><span class="nm">' + nm + '</span></button>';
  }

  /* ---------- routeur ---------- */
  function parse() {
    var raw = (location.hash || '#/home').slice(1);
    var qi = raw.indexOf('?');
    var query = {};
    if (qi >= 0) {
      raw.slice(qi + 1).split('&').forEach(function (kv) {
        var p = kv.split('=');
        query[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || '');
      });
      raw = raw.slice(0, qi);
    }
    return { parts: raw.split('/').filter(Boolean), query: query };
  }

  function render() {
    var r = parse();
    var p = r.parts;
    var root = view;
    root.innerHTML = '';
    root.scrollTop = 0;
    window.scrollTo(0, 0);

    var main = ['home', 'clients', 'orders', 'more'];
    var tab = p[0] || 'home';
    tabbar.querySelectorAll('.tab').forEach(function (t) {
      t.classList.toggle('on', t.getAttribute('data-tab') === tab);
    });
    tabbar.classList.toggle('hidden', main.indexOf(tab) === -1 || p.length > 1);

    try {
      if (!p.length || p[0] === 'home') return Dashboard.render(root);
      if (p[0] === 'clients') {
        if (!p[1]) return Clients.list(root);
        if (p[1] === 'new') return Clients.form(root, null);
        if (p[2] === 'edit') return Clients.form(root, p[1]);
        return Clients.details(root, p[1]);
      }
      if (p[0] === 'orders') {
        if (!p[1]) return Orders.list(root);
        if (p[1] === 'new') return Orders.form(root, null, r.query);
        if (p[2] === 'edit') return Orders.form(root, p[1], r.query);
        return Orders.details(root, p[1]);
      }
      if (p[0] === 'articles') return Articles.list(root);
      if (p[0] === 'payments') return Payments.list(root);
      if (p[0] === 'deliveries') return Deliveries.list(root);
      if (p[0] === 'documents') return Documents.list(root);
      if (p[0] === 'more') return more(root);
      root.innerHTML = '<p class="sub" style="padding:40px 0;text-align:center">Page introuvable.</p>';
    } catch (e) {
      console.error(e);
      root.innerHTML = '<p class="sub" style="padding:40px 0;text-align:center">Une erreur est survenue.</p>';
    }
  }

  /* ---------- données de démonstration ---------- */
  function seed() {
    var s = Store.state;
    if (s.clients.length || s.orders.length || s.articles.length) return Promise.resolve();

    var now = new Date();
    function dayISO(back) {
      var d = new Date(now.getTime() - back * 86400000);
      return d.toISOString().slice(0, 10);
    }

    var clients = [
      { name: 'Alimentation El Baraka', contact: 'Karim Belhadj', phone: '0555 12 34 56', city: 'Alger', address: 'Rue Didouche Mourad' },
      { name: 'Supérette Nour', contact: 'Nadia Hamdi', phone: '0661 98 74 12', city: 'Blida', address: 'Cité 200 logements' },
      { name: 'Épicerie Ammi Salah', contact: 'Salah Zerrouki', phone: '0770 45 22 90', city: 'Boumerdès', address: 'Centre-ville' },
      { name: 'Distribution Atlas', contact: 'Yacine Meziane', phone: '0540 33 11 08', city: 'Oran', address: 'Zone d\'activité' }
    ].map(function (c, i) {
      return Object.assign({ id: U.uid(), code: 'CLI-' + String(i + 1).padStart(3, '0'), active: true, createdAt: new Date().toISOString() }, c);
    });

    var articles = [
      { name: 'Huile de table 5L', reference: 'HUI-5L', category: 'Épicerie' },
      { name: 'Semoule fine 10kg', reference: 'SEM-10', category: 'Épicerie' },
      { name: 'Café moulu 250g', reference: 'CAF-250', category: 'Boissons' },
      { name: 'Eau minérale 1.5L (pack 6)', reference: 'EAU-P6', category: 'Boissons' },
      { name: 'Détergent 2L', reference: 'DET-2L', category: 'Entretien' }
    ].map(function (a) {
      return Object.assign({ id: U.uid(), description: '', createdAt: new Date().toISOString() }, a);
    });

    function line(a, qty, amt) {
      return { articleId: a.id, articleName: a.name, reference: a.reference, quantity: qty, unitAmount: amt, total: qty * amt };
    }

    var orders = [
      { client: clients[0], items: [line(articles[0], 12, 950), line(articles[1], 5, 1200)], status: 'a_livrer', back: 1 },
      { client: clients[1], items: [line(articles[2], 20, 380), line(articles[3], 10, 260)], status: 'en_livraison', back: 3 },
      { client: clients[2], items: [line(articles[4], 8, 640)], status: 'livree', back: 6, delivered: true },
      { client: clients[3], items: [line(articles[0], 30, 930), line(articles[4], 12, 620)], status: 'a_livrer', back: 8 }
    ].map(function (o, i) {
      var total = o.items.reduce(function (t, it) { return t + it.total; }, 0);
      return {
        id: U.uid(), number: 'CMD-' + String(i + 1).padStart(3, '0'),
        clientId: o.client.id, clientName: o.client.name,
        date: dayISO(o.back), items: o.items, total: total,
        status: o.status, notes: '',
        deliveredAt: o.delivered ? new Date(now.getTime() - o.back * 86400000).toISOString() : null,
        createdAt: new Date(now.getTime() - o.back * 86400000).toISOString()
      };
    });

    var payments = [
      { orderId: orders[2].id, clientId: orders[2].clientId, amount: orders[2].total, mode: 'especes', date: dayISO(5) },
      { orderId: orders[1].id, clientId: orders[1].clientId, amount: 5000, mode: 'cheque', date: dayISO(2) }
    ].map(function (p) {
      return Object.assign({ id: U.uid(), note: '', createdAt: new Date().toISOString() }, p);
    });

    var jobs = []
      .concat(clients.map(function (c) { return Store.save('clients', c); }))
      .concat(articles.map(function (a) { return Store.save('articles', a); }))
      .concat(orders.map(function (o) { return Store.save('orders', o); }))
      .concat(payments.map(function (p) { return Store.save('payments', p); }));
    return Promise.all(jobs);
  }

  /* ---------- démarrage ---------- */
  window.addEventListener('hashchange', render);

  Store.open()
    .then(Store.load)
    .then(seed)
    .then(function () {
      if (!location.hash) location.hash = '#/home';
      render();
    })
    .catch(function (e) {
      console.error(e);
      view.innerHTML = '<p class="sub" style="padding:40px 0;text-align:center">Stockage indisponible sur cet appareil.</p>';
    });

  /* Service worker : uniquement en production, jamais dans un aperçu intégré */
  if ('serviceWorker' in navigator) {
    var h = location.hostname;
    var blocked = window.top !== window.self ||
      h === 'localhost' || h === '127.0.0.1' ||
      h.indexOf('id-preview--') === 0 || h.indexOf('preview--') === 0 ||
      /(^|\.)lovableproject(-dev)?\.com$/.test(h) ||
      location.search.indexOf('sw=off') !== -1;
    if (blocked) {
      navigator.serviceWorker.getRegistrations().then(function (rs) {
        rs.forEach(function (r) {
          if (r.active && r.active.scriptURL.indexOf('/commercia/service-worker.js') !== -1) r.unregister();
        });
      });
    } else {
      window.addEventListener('load', function () {
        navigator.serviceWorker.register('./service-worker.js').catch(function () {});
      });
    }
  }
})();
