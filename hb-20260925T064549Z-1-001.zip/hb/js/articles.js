/* Articles : catalogue sans prix ni stock */
window.Articles = (function () {

  function card(a, onClick) {
    var b = document.createElement('button');
    b.className = 'card tap';
    b.innerHTML =
      '<div class="list-item"><div class="avatar">' + I.box + '</div><div style="flex:1;min-width:0">' +
      '<h3>' + U.esc(a.name) + '</h3><div class="sub">' + U.esc(a.reference) +
      (a.category ? ' • ' + U.esc(a.category) : '') + '</div></div></div>' +
      (a.description ? '<div class="small muted" style="margin-top:8px">' + U.esc(a.description) + '</div>' : '');
    if (onClick) b.onclick = function () { onClick(a); };
    return b;
  }

  function list(root) {
    root.innerHTML =
      UI.topbar('Articles') +
      '<div class="search"><span class="ic">' + I.search + '</span><input id="q" type="search" placeholder="Rechercher un article..." /></div>' +
      '<div id="list"></div><button class="fab" id="fab">+</button>';
    UI.bindBack(root);
    var box = root.querySelector('#list'), q = root.querySelector('#q');

    function draw() {
      box.innerHTML = '';
      var items = Store.state.articles.filter(function (a) {
        return U.match([a.name, a.reference, a.category], q.value);
      }).sort(function (a, b) { return a.name.localeCompare(b.name); });
      if (!items.length) {
        box.appendChild(UI.emptyState('' + I.box + '', 'Aucun article', 'Ajoutez votre premier article.', '+ Ajouter un article', openForm));
        return;
      }
      items.forEach(function (a) { box.appendChild(card(a, function () { openForm(a); })); });
    }

    function openForm(a) {
      var art = a && a.id ? a : null;
      UI.sheet({
        title: art ? 'Modifier l\'article' : 'Ajouter un article',
        body:
          '<form id="af">' +
          '<label class="field"><span>Nom *</span><input name="name" required value="' + U.esc(art ? art.name : '') + '" /></label>' +
          '<label class="field"><span>Référence *</span><input name="reference" required value="' + U.esc(art ? art.reference : '') + '" /></label>' +
          '<label class="field"><span>Catégorie</span><input name="category" value="' + U.esc(art ? art.category : '') + '" /></label>' +
          '<label class="field"><span>Description</span><textarea name="description">' + U.esc(art ? art.description : '') + '</textarea></label>' +
          '<button class="btn" type="submit">Enregistrer</button>' +
          (art ? '<div style="height:10px"></div><button class="btn ghost" type="button" id="del" style="color:var(--red)">Supprimer</button>' : '') +
          '</form>',
        onMount: function (el, close) {
          el.querySelector('#af').onsubmit = function (e) {
            e.preventDefault();
            var fd = new FormData(e.target);
            var obj = art ? Object.assign({}, art) : { id: U.uid(), createdAt: new Date().toISOString() };
            obj.name = (fd.get('name') || '').toString().trim();
            obj.reference = (fd.get('reference') || '').toString().trim();
            obj.category = (fd.get('category') || '').toString().trim();
            obj.description = (fd.get('description') || '').toString().trim();
            Store.save('articles', obj).then(function () {
              close(); UI.toast(art ? 'Article modifié ✓' : 'Article ajouté ✓'); draw();
            });
          };
          var d = el.querySelector('#del');
          if (d) d.onclick = function () {
            close();
            UI.confirm({ title: 'Supprimer cet article ?', text: 'Cette action est irréversible.' }).then(function (ok) {
              if (!ok) return;
              Store.remove('articles', art.id).then(function () { UI.toast('Article supprimé ✓'); draw(); });
            });
          };
        }
      });
    }

    q.oninput = draw;
    root.querySelector('#fab').onclick = function () { openForm(); };
    draw();
  }

  /* Sélecteur d'article pour une commande */
  function picker(onPick) {
    UI.sheet({
      title: 'Ajouter un article',
      body: '<div class="search"><span class="ic">' + I.search + '</span><input id="aq" type="search" placeholder="Rechercher un article..." /></div><div id="al"></div>',
      onMount: function (el, close) {
        var q = el.querySelector('#aq'), box = el.querySelector('#al');
        function draw() {
          box.innerHTML = '';
          var items = Store.state.articles.filter(function (a) { return U.match([a.name, a.reference, a.category], q.value); });
          if (!items.length) { box.innerHTML = '<p class="sub" style="padding:20px 0;text-align:center">Aucun article trouvé.</p>'; return; }
          items.forEach(function (a) {
            box.appendChild(card(a, function () { close(); amountSheet(a, onPick); }));
          });
        }
        q.oninput = draw; draw();
      }
    });
  }

  function amountSheet(a, onPick) {
    UI.sheet({
      title: a.name,
      body:
        '<p class="sub" style="margin-bottom:14px">' + U.esc(a.reference) + '</p>' +
        '<form id="qf">' +
        '<label class="field"><span>Quantité</span><input name="qty" type="number" inputmode="numeric" min="1" step="1" value="1" required /></label>' +
        '<label class="field"><span>Montant unitaire (DA)</span><input name="amt" type="number" inputmode="numeric" min="0" step="1" placeholder="0" required /></label>' +
        '<div class="total-bar"><span class="t">Total ligne</span><span class="a" id="tl">0 DA</span></div>' +
        '<button class="btn" type="submit">Ajouter à la commande</button></form>',
      onMount: function (el, close) {
        var f = el.querySelector('#qf');
        var out = el.querySelector('#tl');
        function calc() {
          var q = Number(f.qty.value || 0), m = Number(f.amt.value || 0);
          out.textContent = U.formatCurrency(q * m);
        }
        f.qty.oninput = calc; f.amt.oninput = calc;
        f.onsubmit = function (e) {
          e.preventDefault();
          var q = Math.max(1, Number(f.qty.value || 1)), m = Math.max(0, Number(f.amt.value || 0));
          close();
          onPick({ articleId: a.id, articleName: a.name, reference: a.reference, quantity: q, unitAmount: m, total: q * m });
        };
      }
    });
  }

  return { list: list, picker: picker, card: card };
})();
