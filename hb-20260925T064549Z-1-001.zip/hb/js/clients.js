/* Clients : liste, fiche, formulaire */
window.Clients = (function () {

  /* Versement du client (non lié à une commande ou affecté) : diminue son reste à payer */
  function versementSheet(c, done) {
    var reste = Store.clientRemaining(c.id);
    var unpaidOrders = Store.clientOrders(c.id).filter(function (o) { return Store.remainingOf(o) > 0; });
    var orderOptions = unpaidOrders.length
      ? '<label class="field"><span>Affecter à la commande</span><select name="orderId" id="vf-order">' +
        '<option value="">Automatique (compte client • déduit des commandes)</option>' +
        unpaidOrders.map(function (o) {
          return '<option value="' + o.id + '" data-rem="' + Store.remainingOf(o) + '">' + U.esc(o.number) + ' — Reste : ' + U.formatCurrency(Store.remainingOf(o)) + '</option>';
        }).join('') +
        '</select></label>'
      : '';

    UI.sheet({
      title: 'Versement de ' + c.name,
      body:
        '<p class="sub" style="margin-bottom:14px">Reste à payer actuel : <strong>' + U.formatCurrency(reste) + '</strong></p>' +
        '<form id="vf">' +
        orderOptions +
        '<label class="field"><span>Montant (DA) *</span><input id="vf-amount" name="amount" type="number" inputmode="numeric" min="1" step="1" value="' + (reste > 0 ? reste : '') + '" required /></label>' +
        '<label class="field"><span>Date</span><input name="date" type="date" value="' + U.todayISO() + '" /></label>' +
        '<div class="radios" style="margin-bottom:14px">' +
          Object.keys(Payments.MODES).map(function (k, i) {
            return '<label class="' + (i === 0 ? 'on' : '') + '"><input type="radio" name="mode" value="' + k + '" ' + (i === 0 ? 'checked' : '') + ' />' + Payments.MODES[k] + '</label>';
          }).join('') +
        '</div>' +
        '<label class="field"><span>Note</span><input name="note" /></label>' +
        '<button class="btn green" type="submit">Enregistrer le versement</button></form>',
      onMount: function (el, close) {
        var ordSelect = el.querySelector('#vf-order');
        var amtInput = el.querySelector('#vf-amount');
        if (ordSelect) {
          ordSelect.onchange = function () {
            var opt = ordSelect.options[ordSelect.selectedIndex];
            var rem = opt.getAttribute('data-rem');
            if (rem) amtInput.value = rem;
            else amtInput.value = (reste > 0 ? reste : '');
          };
        }
        el.querySelectorAll('.radios label').forEach(function (l) {
          l.onclick = function () {
            el.querySelectorAll('.radios label').forEach(function (x) { x.classList.remove('on'); });
            l.classList.add('on');
          };
        });
        el.querySelector('#vf').onsubmit = function (e) {
          e.preventDefault();
          var fd = new FormData(e.target);
          var amount = Number(fd.get('amount') || 0);
          var selectedOrderId = (fd.get('orderId') || '').toString().trim() || null;
          if (amount <= 0) return UI.toast('Montant invalide');
          var p = {
            id: U.uid(), clientId: c.id, orderId: selectedOrderId,
            amount: amount, date: (fd.get('date') || U.todayISO()).toString(),
            mode: (fd.get('mode') || 'especes').toString(),
            note: (fd.get('note') || '').toString().trim(),
            createdAt: new Date().toISOString()
          };
          Store.save('payments', p).then(function () {
            close();
            UI.toast('Versement enregistré ✓ Nouveau reste : ' + U.formatCurrency(Store.clientRemaining(c.id)));
            if (done) done();
          });
        };
      }
    });
  }

  function card(c) {
    var b = document.createElement('button');
    b.className = 'card tap';
    var nb = Store.clientOrders(c.id).length;
    var reste = Store.clientRemaining(c.id);
    b.innerHTML =
      '<div class="list-item"><div class="avatar">' + I.building + '</div><div style="flex:1;min-width:0">' +
        '<h3>' + U.esc(c.name) + '</h3>' +
        (c.contact ? '<div class="sub">' + U.esc(c.contact) + '</div>' : '') +
        (c.phone ? '<div class="sub">' + I.phone + ' ' + U.esc(c.phone) + '</div>' : '') +
      '</div></div>' +
      '<div class="divider"></div>' +
      '<div class="between"><span class="small muted">' + nb + ' commande' + (nb > 1 ? 's' : '') + '</span>' +
      '<span class="' + (reste > 0 ? 'amount red' : 'amount green') + '" style="font-size:16px">' + U.formatCurrency(reste) + '</span></div>';
    b.onclick = function () { location.hash = '#/clients/' + c.id; };
    return b;
  }

  function list(root) {
    root.innerHTML =
      '<h1>Clients</h1>' +
      '<div class="search"><span class="ic">' + I.search + '</span><input id="q" type="search" placeholder="Rechercher un client..." /></div>' +
      '<div id="list"></div>' +
      '<button class="fab" id="fab">+</button>';
    var box = root.querySelector('#list');
    var q = root.querySelector('#q');

    function draw() {
      box.innerHTML = '';
      var items = Store.state.clients.filter(function (c) {
        return U.match([c.name, c.contact, c.phone, c.phone2, c.city, c.code], q.value);
      }).sort(function (a, b) { return a.name.localeCompare(b.name); });
      if (!items.length) {
        box.appendChild(UI.emptyState('' + I.users + '', 'Aucun client', 'Ajoutez votre premier client.', '+ Ajouter un client', function () {
          location.hash = '#/clients/new';
        }));
        return;
      }
      items.forEach(function (c) { box.appendChild(card(c)); });
    }
    q.oninput = draw;
    root.querySelector('#fab').onclick = function () { location.hash = '#/clients/new'; };
    draw();
  }

  var FIELDS = [
    ['name', 'Nom / Société', 'text', true],
    ['contact', 'Contact', 'text'],
    ['phone', 'Téléphone', 'tel'],
    ['phone2', 'Téléphone 2', 'tel'],
    ['email', 'Email', 'email'],
    ['address', 'Adresse', 'text'],
    ['city', 'Ville', 'text'],
    ['nif', 'NIF', 'text'],
    ['rc', 'RC', 'text'],
    ['notes', 'Notes', 'textarea']
  ];

  function form(root, id) {
    var existing = id ? Store.client(id) : null;
    var c = existing || {};
    root.innerHTML =
      UI.topbar(existing ? 'Modifier le client' : 'Ajouter un client') +
      '<form id="f">' +
      FIELDS.map(function (f) {
        var val = U.esc(c[f[0]] || '');
        var input = f[2] === 'textarea'
          ? '<textarea name="' + f[0] + '">' + val + '</textarea>'
          : '<input name="' + f[0] + '" type="' + f[2] + '" value="' + val + '" ' + (f[3] ? 'required' : '') + ' />';
        return '<label class="field"><span>' + f[1] + (f[3] ? ' *' : '') + '</span>' + input + '</label>';
      }).join('') +
      '<div class="sticky-action"><button class="btn" type="submit">Enregistrer</button></div>' +
      '</form>';
    UI.bindBack(root);

    root.querySelector('#f').onsubmit = function (e) {
      e.preventDefault();
      var fd = new FormData(e.target);
      var obj = existing ? Object.assign({}, existing) : {
        id: U.uid(), code: Store.nextClientCode(), active: true, createdAt: new Date().toISOString()
      };
      FIELDS.forEach(function (f) { obj[f[0]] = (fd.get(f[0]) || '').toString().trim(); });
      if (!obj.name) return UI.toast('Le nom est obligatoire');
      Store.save('clients', obj).then(function () {
        UI.toast(existing ? 'Client modifié ✓' : 'Client ajouté ✓');
        location.hash = '#/clients/' + obj.id;
      });
    };
  }

  function details(root, id) {
    var c = Store.client(id);
    if (!c) { root.innerHTML = '<p class="sub" style="padding:40px 0">Client introuvable.</p>'; return; }
    var orders = Store.clientOrders(id);
    var reste = Store.clientRemaining(id);

    root.innerHTML =
      UI.topbar('Client') +
      '<div class="card"><div class="list-item"><div class="avatar" style="width:54px;height:54px;font-size:24px">' + I.building + '</div>' +
        '<div style="flex:1;min-width:0"><h3 style="font-size:19px">' + U.esc(c.name) + '</h3>' +
        (c.contact ? '<div class="sub">' + U.esc(c.contact) + '</div>' : '') + '</div></div>' +
        (c.phone ? '<div class="divider"></div><a class="btn soft" href="tel:' + U.esc(c.phone) + '" style="text-decoration:none">' + I.phone + ' ' + U.esc(c.phone) + '</a>' : '') +
      '</div>' +
      '<div class="stats">' +
        '<div class="stat"><div class="lbl">' + I.cart + ' Commandes</div><div class="val">' + orders.length + '</div></div>' +
        '<div class="stat"><div class="lbl">' + I.card + ' À payer</div><div class="val sm">' + U.formatCurrency(reste) + '</div></div>' +
      '</div>' +
      '<button class="btn" id="new-order" style="margin-top:14px">+ Nouvelle commande</button>' +
      '<div style="height:10px"></div>' +
      '<button class="btn green" id="versement">' + I.cash + ' Ajouter un versement</button>' +
      '<div class="segment" style="margin-top:14px"><button data-t="orders" class="on">Commandes</button><button data-t="pay">Paiements</button><button data-t="info">Infos</button></div>' +
      '<div id="tabbox"></div>' +
      '<div style="height:10px"></div>' +
      '<button class="btn ghost" id="edit">Modifier le client</button>' +
      '<div style="height:10px"></div>' +
      '<button class="btn ghost" id="del" style="color:var(--red)">Supprimer le client</button>';
    UI.bindBack(root);

    root.querySelector('#new-order').onclick = function () { location.hash = '#/orders/new?client=' + c.id; };
    root.querySelector('#versement').onclick = function () {
      versementSheet(c, function () { details(root, id); });
    };
    root.querySelector('#edit').onclick = function () { location.hash = '#/clients/' + c.id + '/edit'; };
    root.querySelector('#del').onclick = function () {
      UI.confirm({ title: 'Supprimer ce client ?', text: 'Cette action est irréversible. Les commandes liées seront conservées.' })
        .then(function (ok) {
          if (!ok) return;
          Store.remove('clients', c.id).then(function () { UI.toast('Client supprimé ✓'); location.hash = '#/clients'; });
        });
    };

    var box = root.querySelector('#tabbox');
    var btns = root.querySelectorAll('.segment button');
    btns.forEach(function (b) {
      b.onclick = function () {
        btns.forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        drawTab(b.getAttribute('data-t'));
      };
    });

    function drawTab(t) {
      box.innerHTML = '';
      if (t === 'orders') {
        if (!orders.length) return box.appendChild(UI.emptyState('' + I.cart + '', 'Aucune commande', 'Créez la première commande de ce client.'));
        orders.forEach(function (o) { box.appendChild(Orders.card(o, true)); });
      } else if (t === 'pay') {
        var ps = Store.clientPayments(id);
        if (!ps.length) return box.appendChild(UI.emptyState('' + I.card + '', 'Aucun paiement', 'Aucun paiement enregistré.'));
        ps.forEach(function (p) { box.appendChild(Payments.card(p)); });
      } else {
        box.innerHTML = '<div class="card">' +
          kv('Code', c.code) + kv('Contact', c.contact) + kv('Téléphone', c.phone) + kv('Téléphone 2', c.phone2) +
          kv('Email', c.email) + kv('Adresse', c.address) + kv('Ville', c.city) + kv('NIF', c.nif) + kv('RC', c.rc) +
          kv('Notes', c.notes) + kv('Créé le', U.formatDate(c.createdAt)) + '</div>';
      }
    }
    function kv(k, v) {
      return '<div class="kv"><span class="k">' + k + '</span><span class="v">' + U.esc(v || '—') + '</span></div>';
    }
    drawTab('orders');
  }

  /* Sélecteur de client (bottom sheet) */
  function picker(onPick) {
    UI.sheet({
      title: 'Choisir un client',
      body: '<div class="search"><span class="ic">' + I.search + '</span><input id="cq" type="search" placeholder="Rechercher..." /></div><div id="cl"></div>',
      onMount: function (el, close) {
        var q = el.querySelector('#cq'), box = el.querySelector('#cl');
        function draw() {
          box.innerHTML = '';
          var items = Store.state.clients.filter(function (c) { return U.match([c.name, c.contact, c.phone], q.value); });
          if (!items.length) { box.innerHTML = '<p class="sub" style="padding:20px 0;text-align:center">Aucun client trouvé.</p>'; return; }
          items.forEach(function (c) {
            var b = document.createElement('button');
            b.className = 'card tap';
            b.innerHTML = '<div class="list-item"><div class="avatar">' + I.building + '</div><div><h3>' + U.esc(c.name) + '</h3>' +
              '<div class="sub">' + U.esc(c.contact || c.phone || '') + '</div></div></div>';
            b.onclick = function () { close(); onPick(c); };
            box.appendChild(b);
          });
        }
        q.oninput = draw;
        draw();
      }
    });
  }

  return { list: list, form: form, details: details, card: card, picker: picker };
})();
