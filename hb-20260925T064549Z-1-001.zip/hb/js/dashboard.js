/* Accueil / tableau de bord */
window.Dashboard = (function () {
  function render(root) {
    var s = Store.state;
    var aPayer = Store.globalRemaining();
    var livraisons = s.orders.filter(function (o) { return o.status !== 'livree'; }).length;
    var recent = s.orders.slice().sort(function (a, b) {
      return (b.createdAt || b.date || '').localeCompare(a.createdAt || a.date || '');
    }).slice(0, 5);

    var recentPayments = s.payments.slice().sort(function (a, b) {
      return (b.date || b.createdAt || '').localeCompare(a.date || a.createdAt || '');
    }).slice(0, 3);

    root.innerHTML =
      '<h1>Bonjour</h1><p class="sub">Voici votre activité</p>' +
      '<div class="stats" style="margin-top:16px">' +
        stat('' + I.users + '', 'Clients', U.formatNumber(s.clients.length), '#/clients') +
        stat('' + I.cart + '', 'Commandes', U.formatNumber(s.orders.length), '#/orders') +
        stat('' + I.card + '', 'À payer', U.formatCurrency(aPayer), '#/payments', true) +
        stat('' + I.truck + '', 'Livraisons', U.formatNumber(livraisons), '#/deliveries') +
      '</div>' +
      '<h2>Dernières commandes</h2>' +
      '<div id="recent"></div>' +
      '<div class="between" style="margin-top:24px"><h2 style="margin:0">Derniers paiements & versements</h2><button class="btn sm soft" data-go="#/payments">Voir tout</button></div>' +
      '<div id="recent-payments" style="margin-top:12px"></div>';

    root.querySelectorAll('[data-go]').forEach(function (b) {
      b.onclick = function () { location.hash = b.getAttribute('data-go'); };
    });

    var box = root.querySelector('#recent');
    if (!recent.length) {
      box.appendChild(UI.emptyState('' + I.cart + '', 'Aucune commande', 'Créez votre première commande.', '+ Nouvelle commande', function () {
        location.hash = '#/orders/new';
      }));
    } else {
      recent.forEach(function (o) { box.appendChild(Orders.card(o)); });
    }

    var payBox = root.querySelector('#recent-payments');
    if (!recentPayments.length) {
      payBox.innerHTML = '<p class="sub" style="padding:10px 0 20px">Aucun versement ou paiement enregistré.</p>';
    } else {
      recentPayments.forEach(function (p) { payBox.appendChild(Payments.card(p)); });
    }
  }

  function stat(icon, label, value, go, small) {
    return '<button class="stat" data-go="' + go + '"><div class="lbl">' + icon + ' ' + label + '</div>' +
      '<div class="val' + (small ? ' sm' : '') + '">' + U.esc(value) + '</div></button>';
  }

  return { render: render };
})();
