/* Livraisons : suivi + photo obligatoire du bon de livraison */
window.Deliveries = (function () {

  function list(root) {
    var s = Store.state;
    var pending = s.orders.filter(function (o) { return o.status !== 'livree'; });
    var done = s.orders.filter(function (o) { return o.status === 'livree'; });

    root.innerHTML =
      UI.topbar('Livraisons') +
      '<div class="stats">' +
        '<div class="stat"><div class="lbl">' + I.truck + ' À livrer</div><div class="val">' + pending.length + '</div></div>' +
        '<div class="stat"><div class="lbl">' + I.dot + ' Livrées</div><div class="val">' + done.length + '</div></div>' +
      '</div>' +
      '<div class="segment"><button data-t="todo" class="on">À livrer</button><button data-t="done">Livrées</button></div>' +
      '<div id="box"></div>';
    UI.bindBack(root);

    var box = root.querySelector('#box');
    var btns = root.querySelectorAll('.segment button');
    btns.forEach(function (b) {
      b.onclick = function () {
        btns.forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        draw(b.getAttribute('data-t'));
      };
    });

    function draw(t) {
      box.innerHTML = '';
      var items = (t === 'todo' ? pending : done)
        .sort(function (a, b) { return (b.date || '').localeCompare(a.date || ''); });
      if (!items.length) {
        return box.appendChild(UI.emptyState('' + I.truck + '', t === 'todo' ? 'Aucune livraison en attente' : 'Aucune livraison effectuée',
          t === 'todo' ? 'Toutes les commandes sont livrées.' : 'Les commandes livrées apparaîtront ici.'));
      }
      items.forEach(function (o) { box.appendChild(Orders.card(o)); });
    }
    draw('todo');
  }

  /* Workflow : confirmation → photo (recommandée) → aperçu → confirmer → sauvegarde */
  function markDelivered(order, done) {
    UI.sheet({
      title: 'Confirmation de livraison',
      body:
        '<p class="sub" style="margin-bottom:16px">Commande ' + U.esc(order.number) + '.<br>' +
        'La photo du bon de livraison signé est <strong>recommandée</strong> mais facultative.</p>' +
        '<button class="btn" id="shoot">' + I.camera + ' Photographier le bon</button>' +
        '<div style="height:10px"></div><button class="btn green" id="nophoto">' + I.check + ' Confirmer sans photo</button>' +
        '<div style="height:10px"></div><button class="btn ghost" id="cancel">Annuler</button>' +
        '<input id="file" type="file" accept="image/*" capture="environment" class="hidden" />',
      onMount: function (el, close) {
        var file = el.querySelector('#file');
        el.querySelector('#cancel').onclick = close;
        el.querySelector('#shoot').onclick = function () { file.click(); };
        el.querySelector('#nophoto').onclick = function () {
          close();
          confirmDelivery(order, null, done);
        };
        file.onchange = function () {
          var f = file.files && file.files[0];
          file.value = '';
          if (!f) return;
          UI.toast('Traitement de la photo...');
          U.compressImage(f, 1600, 0.82).then(function (res) {
            close();
            preview(order, res, done);
          }).catch(function () { UI.toast('Photo illisible, réessayez'); });
        };
      }
    });
  }

  /* Enregistre la livraison, avec ou sans bon photographié */
  function confirmDelivery(order, photo, done) {
    var now = new Date().toISOString();
    var jobs = [];
    if (photo) {
      jobs.push(Store.save('documents', {
        id: U.uid(), fileName: photo.name, fileType: photo.type, fileSize: photo.size,
        data: photo.data, relatedType: 'order', relatedId: order.id,
        orderId: order.id, clientId: order.clientId, type: 'bon_livraison', createdAt: now
      }));
    }
    return Promise.all(jobs)
      .then(function () {
        return Store.save('orders', Object.assign({}, order, { status: 'livree', deliveredAt: now }));
      })
      .then(function () {
        UI.toast(photo ? 'Livrée ✓ Bon de livraison enregistré' : 'Livrée ✓');
        if (done) done();
      })
      .catch(function () { UI.toast('Enregistrement impossible'); });
  }

  function preview(order, photo, done) {
    UI.sheet({
      title: 'Aperçu du bon',
      body:
        '<img class="thumb" src="' + photo.data + '" alt="Bon de livraison" />' +
        '<p class="small muted" style="margin:10px 0 16px">' + U.esc(photo.name) + ' • ' + Math.round(photo.size / 1024) + ' Ko</p>' +
        '<button class="btn green" id="ok">' + I.check + ' Confirmer la livraison</button>' +
        '<div style="height:10px"></div><button class="btn ghost" id="again">' + I.refresh + ' Reprendre la photo</button>' +
        '<div style="height:10px"></div><button class="btn ghost" id="cancel">Annuler</button>',
      onMount: function (el, close) {
        el.querySelector('#cancel').onclick = close;
        el.querySelector('#again').onclick = function () { close(); markDelivered(order, done); };
        el.querySelector('#ok').onclick = function () {
          close();
          confirmDelivery(order, photo, done);
        };
      }
    });
  }

  return { list: list, markDelivered: markDelivered };
})();
