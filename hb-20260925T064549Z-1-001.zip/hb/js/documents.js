/* Documents : bons de livraison et pièces jointes */
window.Documents = (function () {

  function list(root) {
    root.innerHTML =
      UI.topbar('Documents') +
      '<div class="search"><span class="ic">' + I.search + '</span><input id="q" type="search" placeholder="Rechercher (commande, client)..." /></div>' +
      '<div id="list"></div>';
    UI.bindBack(root);

    var box = root.querySelector('#list'), q = root.querySelector('#q');

    function draw() {
      box.innerHTML = '';
      var items = Store.state.documents.filter(function (d) {
        var o = Store.order(d.orderId), c = Store.client(d.clientId);
        return U.match([d.fileName, o && o.number, c && c.name], q.value);
      }).sort(function (a, b) { return (b.createdAt || '').localeCompare(a.createdAt || ''); });

      if (!items.length) {
        return box.appendChild(UI.emptyState('' + I.file + '', 'Aucun document',
          'Les bons de livraison photographiés apparaîtront ici.'));
      }
      items.forEach(function (d) { box.appendChild(card(d, draw)); });
    }

    q.oninput = draw;
    draw();
  }

  function card(d, refresh) {
    var o = Store.order(d.orderId), c = Store.client(d.clientId);
    var el = document.createElement('div');
    el.className = 'card';
    el.innerHTML =
      '<div class="list-item"><div class="avatar">' + (d.fileType === 'application/pdf' ? '' + I.filePdf + '' : '' + I.file + '') + '</div>' +
      '<div style="flex:1;min-width:0"><h3>' + U.esc(o ? 'Bon ' + o.number : d.fileName) + '</h3>' +
      '<div class="sub">' + U.esc(c ? c.name : '—') + ' • ' + U.formatDate(d.createdAt) + '</div></div></div>' +
      '<div class="divider"></div>' +
      '<div class="row"><button class="btn sm soft" data-view>Voir</button>' +
      (o ? '<button class="btn sm ghost" data-order>Commande</button>' : '') +
      '<div class="spacer"></div>' +
      '<button class="btn sm ghost" data-del style="color:var(--red)">Supprimer</button></div>';

    el.querySelector('[data-view]').onclick = function () { UI.viewDocument(d.id); };
    var ob = el.querySelector('[data-order]');
    if (ob) ob.onclick = function () { location.hash = '#/orders/' + o.id; };
    el.querySelector('[data-del]').onclick = function () {
      UI.confirm({ title: 'Supprimer ce document ?', text: 'Le bon de livraison sera définitivement supprimé.' })
        .then(function (ok) {
          if (!ok) return;
          Store.remove('documents', d.id).then(function () {
            UI.toast('Document supprimé ✓');
            if (refresh) refresh();
          });
        });
    };
    return el;
  }

  return { list: list, card: card };
})();
