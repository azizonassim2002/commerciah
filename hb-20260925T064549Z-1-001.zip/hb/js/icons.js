/* Jeu d'icônes SVG (trait, couleur héritée) — remplace les emojis */
window.I = (function () {
  function svg(inner, fill) {
    return '<svg class="icon" viewBox="0 0 24 24" fill="' + (fill ? 'currentColor' : 'none') +
      '" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      inner + '</svg>';
  }
  return {
    home: svg('<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.8V20h14V9.8"/><path d="M9.5 20v-5.5h5V20"/>'),
    users: svg('<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.2 2.7-5.2 6-5.2s6 2 6 5.2"/><path d="M16 5.4a3.2 3.2 0 0 1 0 6"/><path d="M17.5 14.6c2.1.6 3.5 2.2 3.5 4.4"/>'),
    cart: svg('<circle cx="9.5" cy="20" r="1.3"/><circle cx="17.5" cy="20" r="1.3"/><path d="M2.5 3.5h2.2l2.3 11h11l2-7.5H6"/>'),
    more: svg('<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>'),
    box: svg('<path d="M20.5 7.5 12 3 3.5 7.5v9L12 21l8.5-4.5z"/><path d="M3.5 7.5 12 12l8.5-4.5M12 12v9"/>'),
    card: svg('<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 9.8h19"/><path d="M6.5 15h4"/>'),
    truck: svg('<path d="M2.5 6.5h11v9h-11z"/><path d="M13.5 10h3.6l2.9 3v2.5h-6.5z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>'),
    file: svg('<path d="M13.5 2.8H7a2 2 0 0 0-2 2v14.4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.3z"/><path d="M13.5 2.8V8.3H19"/><path d="M8.5 13h7M8.5 16.5h5"/>'),
    filePdf: svg('<path d="M13.5 2.8H7a2 2 0 0 0-2 2v14.4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.3z"/><path d="M13.5 2.8V8.3H19"/><path d="M8.6 17v-4h1.3a1.2 1.2 0 0 1 0 2.4H8.6"/><path d="M13 17v-4h1a2 2 0 0 1 0 4z"/>'),
    search: svg('<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>'),
    building: svg('<path d="M4 20.5V5.5A1.5 1.5 0 0 1 5.5 4h7A1.5 1.5 0 0 1 14 5.5v15"/><path d="M14 10h4.5A1.5 1.5 0 0 1 20 11.5v9"/><path d="M2.5 20.5h19"/><path d="M7 8h4M7 12h4M7 16h4M17 14h1M17 17.5h1"/>'),
    calendar: svg('<rect x="3.5" y="5" width="17" height="15.5" rx="2.2"/><path d="M3.5 9.8h17M8 3.2v3.4M16 3.2v3.4"/>'),
    phone: svg('<path d="M6.8 3.5h3l1.4 3.6-2 1.4a12 12 0 0 0 5.3 5.3l1.4-2 3.6 1.4v3a1.8 1.8 0 0 1-2 1.8A15.5 15.5 0 0 1 5 5.5a1.8 1.8 0 0 1 1.8-2z"/>'),
    cash: svg('<rect x="2.5" y="6" width="19" height="12" rx="2.2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 10v4M18 10v4"/>'),
    receipt: svg('<path d="M5.5 3.5h13v17l-2.2-1.4-2.1 1.4-2.2-1.4-2.2 1.4-2.1-1.4-2.2 1.4z"/><path d="M9 8h6M9 12h6"/>'),
    bank: svg('<path d="M3 9.8 12 4l9 5.8"/><path d="M5.5 10.5v7M10 10.5v7M14 10.5v7M18.5 10.5v7"/><path d="M3 20.5h18"/>'),
    check: svg('<path d="m4.5 12.5 5 5 10-11"/>'),
    checkCircle: svg('<circle cx="12" cy="12" r="9"/><path d="m8 12.3 2.8 2.8L16 9.7"/>'),
    camera: svg('<path d="M3 8.5h3.2L8 6h8l1.8 2.5H21v10.5H3z"/><circle cx="12" cy="13.5" r="3.4"/>'),
    eye: svg('<path d="M2.5 12S6 6 12 6s9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z"/><circle cx="12" cy="12" r="2.8"/>'),
    download: svg('<path d="M12 3.5v11"/><path d="m7.5 10.5 4.5 4.5 4.5-4.5"/><path d="M4 20.5h16"/>'),
    trash: svg('<path d="M4.5 6.5h15"/><path d="M9 6.5V4.2h6v2.3"/><path d="M6.5 6.5 7.6 21h8.8l1.1-14.5"/>'),
    refresh: svg('<path d="M20 12a8 8 0 1 1-2.4-5.7"/><path d="M20.5 3.5v4.8h-4.8"/>'),
    plus: svg('<path d="M12 5v14M5 12h14"/>'),
    back: svg('<path d="M15 4.5 7.5 12l7.5 7.5"/>'),
    wave: svg('<path d="M12 3v3M4.9 5.6 7 7.7M19.1 5.6 17 7.7"/><path d="M6.5 12.5a5.5 5.5 0 0 1 11 0V19a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2z"/>'),
    dot: '<span class="dot" aria-hidden="true"></span>'
  };
})();
