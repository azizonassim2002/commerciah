/* Commandes : liste, création, détail */
window.Orders = (function () {

  function card(o, hideClient) {
    var b = document.createElement('button');
    b.className = 'card tap order-card status-' + (o.status || 'a_livrer');
    var c = Store.client(o.clientId);
    var reste = Store.remainingOf(o);
    var doc = Store.orderDoc(o.id);
    b.innerHTML =
      '<div class="between"><strong>' + U.esc(o.number) + '</strong>' + UI.statusBadge(o.status) + '</div>' +
      (hideClient ? '' : '<div class="sub" style="margin-top:6px">' + I.building + ' ' + U.esc(c ? c.name : o.clientName || '—') + '</div>') +
      '<div class="sub">' + I.calendar + ' ' + U.formatDate(o.date) + ' • ' + (o.items || []).length + ' article' + ((o.items || []).length > 1 ? 's' : '') + '</div>' +
      '<div class="divider"></div>' +
      '<div class="between"><span class="small muted">Total ' + U.formatCurrency(o.total) + '</span>' +
      '<span class="' + (reste > 0 ? 'amount red' : 'amount green') + '">' +
      (reste > 0 ? 'Reste ' + U.formatCurrency(reste) : 'Payée ✓') + '</span></div>' +
      (doc ? '<div class="small" style="margin-top:8px;color:var(--green)">' + I.file + ' Bon de livraison enregistré ✓</div>' : '');
    b.onclick = function () { location.hash = '#/orders/' + o.id; };
    return b;
  }

  function list(root) {
    root.innerHTML =
      '<h1>Commandes</h1>' +
      '<div class="search"><span class="ic">' + I.search + '</span><input id="q" type="search" placeholder="Rechercher une commande..." /></div>' +
      '<div class="chips" id="chips">' +
        chip('all', 'Toutes', true) + chip('a_livrer', '' + I.dot + ' À livrer') +
        chip('en_livraison', '' + I.dot + ' En livraison') + chip('livree', '' + I.dot + ' Livrées') +
        chip('impayees', '' + I.card + ' Impayées') +
      '</div>' +
      '<div id="list"></div><button class="fab" id="fab">+</button>';

    var box = root.querySelector('#list'), q = root.querySelector('#q');
    var filter = 'all';

    root.querySelectorAll('.chip').forEach(function (c) {
      c.onclick = function () {
        root.querySelectorAll('.chip').forEach(function (x) { x.classList.remove('on'); });
        c.classList.add('on');
        filter = c.getAttribute('data-f');
        draw();
      };
    });

    function draw() {
      box.innerHTML = '';
      var items = Store.state.orders.filter(function (o) {
        var c = Store.client(o.clientId);
        if (!U.match([o.number, c && c.name, o.notes], q.value)) return false;
        if (filter === 'all') return true;
        if (filter === 'impayees') return Store.remainingOf(o) > 0;
        return o.status === filter;
      }).sort(function (a, b) { return (b.date || '').localeCompare(a.date || ''); });

      if (!items.length) {
        box.appendChild(UI.emptyState('' + I.cart + '', 'Aucune commande', 'Créez votre première commande.', '+ Nouvelle commande', function () {
          location.hash = '#/orders/new';
        }));
        return;
      }
      items.forEach(function (o) { box.appendChild(card(o)); });
    }

    q.oninput = draw;
    root.querySelector('#fab').onclick = function () { location.hash = '#/orders/new'; };
    draw();
  }

  function chip(f, label, on) {
    return '<button class="chip' + (on ? ' on' : '') + '" data-f="' + f + '">' + label + '</button>';
  }

  /* ---------- création / modification ---------- */
  function form(root, id, query) {
    var existing = id ? Store.order(id) : null;
    var draft = existing
      ? { clientId: existing.clientId, date: existing.date, notes: existing.notes || '', items: (existing.items || []).slice() }
      : { clientId: (query && query.client) || '', date: U.todayISO(), notes: '', items: [] };

    root.innerHTML =
      UI.topbar(existing ? 'Modifier la commande' : 'Nouvelle commande') +
      '<div class="card"><div class="between"><span class="sub">Client *</span>' +
      '<button class="btn sm soft" id="pick-client">Choisir</button></div>' +
      '<div id="client-box" style="margin-top:10px"></div></div>' +
      '<label class="field"><span>Date</span><input id="date" type="date" value="' + U.esc(draft.date) + '" /></label>' +
      '<div class="between"><h2 style="margin:0">Articles</h2><button class="btn sm soft" id="add-item">+ Ajouter</button></div>' +
      '<div class="card" id="items" style="margin-top:12px"></div>' +
      '<label class="field" style="margin-top:14px"><span>Notes</span><textarea id="notes">' + U.esc(draft.notes) + '</textarea></label>' +
      '<div class="total-bar"><span class="t">Total commande</span><span class="a" id="total">0 DA</span></div>' +
      '<div class="sticky-action"><button class="btn" id="save">Enregistrer la commande</button></div>';
    UI.bindBack(root);

    var clientBox = root.querySelector('#client-box');
    var itemsBox = root.querySelector('#items');
    var totalEl = root.querySelector('#total');

    function total() {
      return draft.items.reduce(function (s, it) { return s + Number(it.total || 0); }, 0);
    }

    function drawClient() {
      var c = Store.client(draft.clientId);
      clientBox.innerHTML = c
        ? '<div class="list-item"><div class="avatar">' + I.building + '</div><div><h3>' + U.esc(c.name) + '</h3>' +
          '<div class="sub">' + U.esc(c.phone || c.contact || '') + '</div></div></div>'
        : '<p class="sub">Aucun client sélectionné.</p>';
    }

    function drawItems() {
      if (!draft.items.length) {
        itemsBox.innerHTML = '<p class="sub" style="text-align:center;padding:14px 0">Aucun article ajouté.</p>';
      } else {
        itemsBox.innerHTML = draft.items.map(function (it, i) {
          return '<div class="item-line"><div style="min-width:0"><strong>' + U.esc(it.articleName) + '</strong>' +
            '<div class="sub">' + U.esc(it.reference || '') + '</div>' +
            '<div class="small muted">' + it.quantity + ' × ' + U.formatCurrency(it.unitAmount) + '</div></div>' +
            '<div class="right"><div class="amount" style="font-size:16px">' + U.formatCurrency(it.total) + '</div>' +
            '<button class="btn sm ghost" data-del="' + i + '" style="color:var(--red);margin-top:6px">Retirer</button></div></div>';
        }).join('');
        itemsBox.querySelectorAll('[data-del]').forEach(function (b) {
          b.onclick = function () {
            draft.items.splice(Number(b.getAttribute('data-del')), 1);
            drawItems();
          };
        });
      }
      totalEl.textContent = U.formatCurrency(total());
    }

    root.querySelector('#pick-client').onclick = function () {
      Clients.picker(function (c) { draft.clientId = c.id; drawClient(); });
    };
    root.querySelector('#add-item').onclick = function () {
      Articles.picker(function (line) { draft.items.push(line); drawItems(); });
    };

    root.querySelector('#save').onclick = function () {
      draft.date = root.querySelector('#date').value || U.todayISO();
      draft.notes = root.querySelector('#notes').value.trim();
      if (!draft.clientId) return UI.toast('Choisissez un client');
      if (!draft.items.length) return UI.toast('Ajoutez au moins un article');
      var c = Store.client(draft.clientId);
      var obj = existing ? Object.assign({}, existing) : {
        id: U.uid(), number: Store.nextOrderNumber(), status: 'a_livrer', createdAt: new Date().toISOString()
      };
      obj.clientId = draft.clientId;
      obj.clientName = c ? c.name : '';
      obj.date = draft.date;
      obj.notes = draft.notes;
      obj.items = draft.items;
      obj.total = total();
      Store.save('orders', obj).then(function () {
        UI.toast(existing ? 'Commande modifiée ✓' : 'Commande créée ✓');
        location.hash = '#/orders/' + obj.id;
      });
    };

    drawClient();
    drawItems();
  }

  /* ---------- détail ---------- */
  function details(root, id) {
    var o = Store.order(id);
    if (!o) { root.innerHTML = '<p class="sub" style="padding:40px 0">Commande introuvable.</p>'; return; }
    var c = Store.client(o.clientId);
    var paid = Store.paidOf(o.id);
    var reste = Store.remainingOf(o);
    var doc = Store.orderDoc(o.id);
    var pays = Store.orderPayments(o.id);

    root.innerHTML =
      UI.topbar('Commande') +
      '<div class="card"><div class="between"><h3 style="font-size:20px;margin:0">' + U.esc(o.number) + '</h3>' + UI.statusBadge(o.status) + '</div>' +
        '<div class="divider"></div>' +
        '<div class="kv"><span class="k">Client</span><span class="v">' + U.esc(c ? c.name : o.clientName || '—') + '</span></div>' +
        '<div class="kv"><span class="k">Date</span><span class="v">' + U.formatDateLong(o.date) + '</span></div>' +
        (o.deliveredAt ? '<div class="kv"><span class="k">Livrée le</span><span class="v">' + U.formatDateLong(o.deliveredAt) + '</span></div>' : '') +
        (o.notes ? '<div class="divider"></div><div class="small muted">' + U.esc(o.notes) + '</div>' : '') +
      '</div>' +
      '<h2>Articles</h2><div class="card">' +
        (o.items || []).map(function (it) {
          return '<div class="item-line"><div><strong>' + U.esc(it.articleName) + '</strong>' +
            '<div class="small muted">' + it.quantity + ' × ' + U.formatCurrency(it.unitAmount) + '</div></div>' +
            '<div class="amount" style="font-size:16px">' + U.formatCurrency(it.total) + '</div></div>';
        }).join('') +
      '</div>' +
      '<div class="total-bar"><span class="t">Total</span><span class="a">' + U.formatCurrency(o.total) + '</span></div>' +
      '<div class="stats" style="margin-top:12px">' +
        '<div class="stat"><div class="lbl">' + I.check + ' Payé</div><div class="val sm" style="color:var(--green)">' + U.formatCurrency(paid) + '</div></div>' +
        '<div class="stat"><div class="lbl">' + I.card + ' Reste</div><div class="val sm" style="color:' + (reste > 0 ? 'var(--red)' : 'var(--green)') + '">' + U.formatCurrency(reste) + '</div></div>' +
      '</div>' +
      '<h2>Paiements</h2><div id="pays"></div>' +
      (reste > 0 ? '<button class="btn soft" id="add-pay">+ Enregistrer un paiement</button>' : '') +
      '<h2>Bon de livraison</h2><div id="bl"></div>' +
      '<div style="height:14px"></div>' +
      (o.status !== 'livree' ? '<button class="btn green" id="deliver">' + I.check + ' Marquer comme livrée</button><div style="height:10px"></div>' : '') +
      (o.status === 'a_livrer' ? '<button class="btn ghost" id="ship">' + I.truck + ' Mettre en livraison</button><div style="height:10px"></div>' : '') +
      '<button class="btn ghost" id="edit">Modifier la commande</button><div style="height:10px"></div>' +
      '<button class="btn ghost" id="del" style="color:var(--red)">Supprimer la commande</button>';
    UI.bindBack(root);

    var paysBox = root.querySelector('#pays');
    var allocVers = Store.orderAllocatedVersementsList(o.id);
    if (!pays.length && !allocVers.length) {
      paysBox.innerHTML = '<p class="sub" style="padding:6px 0 12px">Aucun paiement enregistré.</p>';
    } else {
      pays.forEach(function (p) { paysBox.appendChild(Payments.card(p)); });
      allocVers.forEach(function (av) {
        var p = av.versement;
        var b = document.createElement('div');
        b.className = 'card';
        b.innerHTML =
          '<div class="between"><div style="min-width:0"><strong>' + U.formatCurrency(av.amount) + '</strong>' +
          '<div class="sub">' + U.esc(Payments.MODES[p.mode] || 'Autre') + ' • ' + U.formatDate(p.date) + '</div>' +
          '<div class="small muted">Versement client imputé' + (p.note ? ' • ' + U.esc(p.note) : '') + '</div></div>' +
          '<span class="badge b-green">✓ Imputé</span></div>';
        paysBox.appendChild(b);
      });
    }

    var blBox = root.querySelector('#bl');
    if (doc) {
      var b = document.createElement('button');
      b.className = 'card tap';
      b.innerHTML = '<div class="list-item"><div class="avatar">' + I.file + '</div><div><h3>Bon de livraison</h3>' +
        '<div class="sub">' + U.formatDate(doc.createdAt) + ' • appuyer pour voir</div></div></div>';
      b.onclick = function () { UI.viewDocument(doc.id); };
      blBox.appendChild(b);
    } else {
      blBox.innerHTML = '<p class="sub" style="padding:6px 0 12px">Aucun bon de livraison enregistré (facultatif).</p>' +
        '<button class="btn soft" id="add-bl">' + I.camera + ' Ajouter le bon</button>' +
        '<input id="bl-file" type="file" accept="image/*" capture="environment" class="hidden" />';
      var bf = blBox.querySelector('#bl-file');
      blBox.querySelector('#add-bl').onclick = function () { bf.click(); };
      bf.onchange = function () {
        var f = bf.files && bf.files[0];
        bf.value = '';
        if (!f) return;
        U.compressImage(f, 1600, 0.82).then(function (ph) {
          return Store.save('documents', {
            id: U.uid(), fileName: ph.name, fileType: ph.type, fileSize: ph.size,
            data: ph.data, relatedType: 'order', relatedId: o.id,
            orderId: o.id, clientId: o.clientId, type: 'bon_livraison', createdAt: new Date().toISOString()
          });
        }).then(function () { UI.toast('Bon de livraison enregistré ✓'); details(root, id); })
          .catch(function () { UI.toast('Photo illisible, réessayez'); });
      };
    }

    var ap = root.querySelector('#add-pay');
    if (ap) ap.onclick = function () { Payments.addSheet(o, function () { details(root, id); }); };

    var sh = root.querySelector('#ship');
    if (sh) sh.onclick = function () {
      var n = Object.assign({}, o, { status: 'en_livraison' });
      Store.save('orders', n).then(function () { UI.toast('Commande en livraison'); details(root, id); });
    };

    var dv = root.querySelector('#deliver');
    if (dv) dv.onclick = function () {
      Deliveries.markDelivered(o, function () { details(root, id); });
    };

    root.querySelector('#edit').onclick = function () { location.hash = '#/orders/' + o.id + '/edit'; };
    root.querySelector('#del').onclick = function () {
      UI.confirm({ title: 'Supprimer cette commande ?', text: 'Les paiements et le bon de livraison liés seront supprimés.' })
        .then(function (ok) {
          if (!ok) return;
          var jobs = [Store.remove('orders', o.id)];
          Store.orderPayments(o.id).forEach(function (p) { jobs.push(Store.remove('payments', p.id)); });
          if (doc) jobs.push(Store.remove('documents', doc.id));
          Promise.all(jobs).then(function () { UI.toast('Commande supprimée ✓'); location.hash = '#/orders'; });
        });
    };
  }

  return { list: list, form: form, details: details, card: card };
})();
