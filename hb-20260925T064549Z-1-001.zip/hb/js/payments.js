/* Paiements : liste, carte, enregistrement */
window.Payments = (function () {

  var MODES = {
    especes: 'Espèces',
    cheque: 'Chèque',
    virement: 'Virement',
    autre: 'Autre'
  };

  function card(p) {
    var o = p.orderId ? Store.order(p.orderId) : null;
    var c = Store.client(p.clientId);
    var b = document.createElement('button');
    b.className = 'card tap';
    b.innerHTML =
      '<div class="between"><div style="min-width:0"><strong>' + U.formatCurrency(p.amount) + '</strong>' +
      '<div class="sub">' + U.esc(MODES[p.mode] || 'Autre') + ' • ' + U.formatDate(p.date) + '</div>' +
      '<div class="small muted">' + (o ? U.esc(o.number) + ' • ' : 'Versement • ') + U.esc(c ? c.name : '') + '</div></div>' +
      '<span class="badge b-green">✓ Reçu</span></div>' +
      (p.note ? '<div class="small muted" style="margin-top:8px">' + U.esc(p.note) + '</div>' : '');
    b.onclick = function () {
      if (o) location.hash = '#/orders/' + o.id;
      else if (p.clientId) location.hash = '#/clients/' + p.clientId;
    };
    return b;
  }

  function list(root) {
    var s = Store.state;
    var total = s.payments.reduce(function (t, p) { return t + Number(p.amount || 0); }, 0);
    var reste = Store.globalRemaining();

    root.innerHTML =
      UI.topbar('Paiements') +
      '<div class="stats">' +
        '<div class="stat"><div class="lbl">' + I.check + ' Encaissé</div><div class="val sm" style="color:var(--green)">' + U.formatCurrency(total) + '</div></div>' +
        '<div class="stat"><div class="lbl">' + I.card + ' À payer</div><div class="val sm" style="color:var(--red)">' + U.formatCurrency(reste) + '</div></div>' +
      '</div>' +
      '<div class="segment"><button data-t="pay" class="on">Paiements</button><button data-t="due">Impayées</button></div>' +
      '<div id="box"></div>';
    UI.bindBack(root);

    var box = root.querySelector('#box');
    var btns = root.querySelectorAll('.segment button');
    btns.forEach(function (b) {
      b.onclick = function () {
        btns.forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        draw(b.getAttribute('data-t'));
      };
    });

    function draw(t) {
      box.innerHTML = '';
      if (t === 'pay') {
        var ps = s.payments.slice().sort(function (a, b) { return (b.date || '').localeCompare(a.date || ''); });
        if (!ps.length) return box.appendChild(UI.emptyState('' + I.card + '', 'Aucun paiement', 'Les paiements enregistrés apparaîtront ici.'));
        ps.forEach(function (p) { box.appendChild(card(p)); });
      } else {
        var os = s.orders.filter(function (o) { return Store.remainingOf(o) > 0; })
          .sort(function (a, b) { return Store.remainingOf(b) - Store.remainingOf(a); });
        if (!os.length) return box.appendChild(UI.emptyState('' + I.check + '', 'Tout est payé', 'Aucune commande impayée.'));
        os.forEach(function (o) { box.appendChild(Orders.card(o)); });
      }
    }
    draw('pay');
  }

  function addSheet(order, done) {
    var reste = Store.remainingOf(order);
    UI.sheet({
      title: 'Enregistrer un paiement',
      body:
        '<p class="sub" style="margin-bottom:14px">' + U.esc(order.number) + ' • Reste ' + U.formatCurrency(reste) + '</p>' +
        '<form id="pf">' +
        '<label class="field"><span>Montant (DA) *</span><input name="amount" type="number" inputmode="numeric" min="1" step="1" value="' + reste + '" required /></label>' +
        '<label class="field"><span>Date</span><input name="date" type="date" value="' + U.todayISO() + '" /></label>' +
        '<div class="radios" style="margin-bottom:14px">' +
          Object.keys(MODES).map(function (k, i) {
            return '<label class="' + (i === 0 ? 'on' : '') + '"><input type="radio" name="mode" value="' + k + '" ' + (i === 0 ? 'checked' : '') + ' />' + MODES[k] + '</label>';
          }).join('') +
        '</div>' +
        '<label class="field"><span>Note</span><input name="note" /></label>' +
        '<button class="btn green" type="submit">Enregistrer le paiement</button></form>',
      onMount: function (el, close) {
        el.querySelectorAll('.radios label').forEach(function (l) {
          l.onclick = function () {
            el.querySelectorAll('.radios label').forEach(function (x) { x.classList.remove('on'); });
            l.classList.add('on');
          };
        });
        el.querySelector('#pf').onsubmit = function (e) {
          e.preventDefault();
          var fd = new FormData(e.target);
          var amount = Number(fd.get('amount') || 0);
          if (amount <= 0) return UI.toast('Montant invalide');
          if (amount > reste) return UI.toast('Montant supérieur au reste à payer');
          var p = {
            id: U.uid(), orderId: order.id, clientId: order.clientId,
            amount: amount, date: (fd.get('date') || U.todayISO()).toString(),
            mode: (fd.get('mode') || 'especes').toString(),
            note: (fd.get('note') || '').toString().trim(),
            createdAt: new Date().toISOString()
          };
          Store.save('payments', p).then(function () {
            close(); UI.toast('Paiement enregistré ✓');
            if (done) done();
          });
        };
      }
    });
  }

  return { list: list, card: card, addSheet: addSheet, MODES: MODES };
})();
