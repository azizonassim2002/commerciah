/* Stockage IndexedDB + état applicatif */
window.Store = (function () {
  var DB_NAME = 'commercia';
  var VERSION = 1;
  var STORES = ['clients', 'articles', 'orders', 'payments', 'documents'];
  var db = null;

  var state = { clients: [], articles: [], orders: [], payments: [], documents: [] };

  function open() {
    return new Promise(function (resolve, reject) {
      var req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = function () {
        var d = req.result;
        STORES.forEach(function (s) {
          if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' });
        });
      };
      req.onsuccess = function () { db = req.result; resolve(db); };
      req.onerror = function () { reject(req.error); };
    });
  }

  function tx(store, mode) {
    return db.transaction(store, mode).objectStore(store);
  }

  function all(store) {
    return new Promise(function (resolve, reject) {
      var r = tx(store, 'readonly').getAll();
      r.onsuccess = function () { resolve(r.result || []); };
      r.onerror = function () { reject(r.error); };
    });
  }

  function put(store, obj) {
    return new Promise(function (resolve, reject) {
      var r = tx(store, 'readwrite').put(obj);
      r.onsuccess = function () { resolve(obj); };
      r.onerror = function () { reject(r.error); };
    });
  }

  function del(store, id) {
    return new Promise(function (resolve, reject) {
      var r = tx(store, 'readwrite').delete(id);
      r.onsuccess = function () { resolve(); };
      r.onerror = function () { reject(r.error); };
    });
  }

  function clear(store) {
    return new Promise(function (resolve, reject) {
      var r = tx(store, 'readwrite').clear();
      r.onsuccess = function () { resolve(); };
      r.onerror = function () { reject(r.error); };
    });
  }

  function getDoc(id) {
    return new Promise(function (resolve, reject) {
      if (!id) return resolve(null);
      var r = tx('documents', 'readonly').get(id);
      r.onsuccess = function () { resolve(r.result || null); };
      r.onerror = function () { reject(r.error); };
    });
  }

  /* ---- chargement en mémoire (les documents sans le binaire) ---- */
  function load() {
    return Promise.all(STORES.map(all)).then(function (res) {
      state.clients = res[0];
      state.articles = res[1];
      state.orders = res[2];
      state.payments = res[3];
      state.documents = res[4].map(function (d) {
        return {
          id: d.id, fileName: d.fileName, fileType: d.fileType, fileSize: d.fileSize,
          relatedType: d.relatedType, relatedId: d.relatedId, orderId: d.orderId,
          clientId: d.clientId, type: d.type, createdAt: d.createdAt
        };
      });
      return state;
    });
  }

  /* ---- écritures ---- */
  function save(store, obj) {
    return put(store, obj).then(function () {
      var list = state[store];
      var i = list.findIndex(function (x) { return x.id === obj.id; });
      var light = obj;
      if (store === 'documents') {
        light = Object.assign({}, obj); delete light.data;
      }
      if (i >= 0) list[i] = light; else list.push(light);
      return obj;
    });
  }

  function remove(store, id) {
    return del(store, id).then(function () {
      state[store] = state[store].filter(function (x) { return x.id !== id; });
    });
  }

  function reset() {
    return Promise.all(STORES.map(clear)).then(load);
  }

  /* ---- sélecteurs ---- */
  function client(id) { return state.clients.find(function (c) { return c.id === id; }) || null; }
  function order(id) { return state.orders.find(function (o) { return o.id === id; }) || null; }
  function article(id) { return state.articles.find(function (a) { return a.id === id; }) || null; }

  function clientOrders(id) {
    return state.orders.filter(function (o) { return o.clientId === id; }).sort(byDateDesc);
  }
  function orderPayments(id) {
    return state.payments.filter(function (p) { return p.orderId === id; }).sort(byDateDesc);
  }
  function clientPayments(id) {
    return state.payments.filter(function (p) { return p.clientId === id; }).sort(byDateDesc);
  }
  function versementsOf(id) {
    return state.payments.filter(function (p) { return p.clientId === id && !p.orderId; });
  }
  function byDateDesc(a, b) { return (b.date || b.createdAt || '').localeCompare(a.date || a.createdAt || ''); }
  function byDateAsc(a, b) { return (a.date || a.createdAt || '').localeCompare(b.date || b.createdAt || ''); }

  /* Paiements directs enregistrés spécifiquement pour une commande */
  function directPaidOf(orderId) {
    return state.payments.reduce(function (s, p) { return p.orderId === orderId ? s + Number(p.amount || 0) : s; }, 0);
  }

  /* Liste et montants des versements clients imputés chronologiquement sur une commande */
  function orderAllocatedVersementsList(orderId) {
    var o = typeof orderId === 'string' ? order(orderId) : orderId;
    if (!o || !o.clientId) return [];
    var clientOrdersList = state.orders.filter(function (x) { return x.clientId === o.clientId; }).slice().sort(byDateAsc);
    var vers = versementsOf(o.clientId).slice().sort(byDateAsc);
    if (!vers.length) return [];

    var versPool = vers.map(function (v) { return { v: v, rem: Number(v.amount || 0) }; });
    var result = [];

    for (var i = 0; i < clientOrdersList.length; i++) {
      var cur = clientOrdersList[i];
      var dPaid = directPaidOf(cur.id);
      var needed = Math.max(0, Number(cur.total || 0) - dPaid);

      for (var j = 0; j < versPool.length && needed > 0; j++) {
        if (versPool[j].rem <= 0) continue;
        var take = Math.min(needed, versPool[j].rem);
        versPool[j].rem -= take;
        needed -= take;
        if (cur.id === o.id) {
          result.push({ versement: versPool[j].v, amount: take });
        }
      }
      if (cur.id === o.id) break;
    }
    return result;
  }

  /* Total des versements clients imputés sur une commande */
  function orderAllocatedVersement(orderId) {
    var list = orderAllocatedVersementsList(orderId);
    return list.reduce(function (s, item) { return s + item.amount; }, 0);
  }

  /* Total payé pour une commande : direct + versements imputés */
  function paidOf(orderId) {
    var o = typeof orderId === 'string' ? order(orderId) : orderId;
    if (!o) return 0;
    return directPaidOf(o.id) + orderAllocatedVersement(o.id);
  }

  /* Reste à payer pour une commande : total - paidOf */
  function remainingOf(o) {
    if (!o) return 0;
    var ord = typeof o === 'string' ? order(o) : o;
    if (!ord) return 0;
    return Math.max(0, Number(ord.total || 0) - paidOf(ord.id));
  }

  /* Reste à payer d'un client : commandes impayées moins ses versements */
  function clientRemaining(id) {
    var due = clientOrders(id).reduce(function (s, o) { return s + remainingOf(o); }, 0);
    return due;
  }

  /* Reste à payer global : somme des restes clients (versements déduits) */
  function globalRemaining() {
    return state.clients.reduce(function (s, c) { return s + clientRemaining(c.id); }, 0);
  }

  function orderDoc(orderId) {
    return state.documents.find(function (d) { return d.relatedId === orderId && d.relatedType === 'order' && d.type === 'bon_livraison'; }) || null;
  }
  function nextOrderNumber() {
    var max = 0;
    state.orders.forEach(function (o) {
      var m = /CMD-(\d+)/.exec(o.number || '');
      if (m) max = Math.max(max, parseInt(m[1], 10));
    });
    return 'CMD-' + String(max + 1).padStart(3, '0');
  }
  function nextClientCode() {
    return 'CLI-' + String(state.clients.length + 1).padStart(3, '0');
  }

  var STATUS = {
    a_livrer: {
      label: 'À livrer',
      key: 'a_livrer',
      cls: 'badge-a_livrer',
      icon: '<svg class="icon icon-status" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>'
    },
    en_livraison: {
      label: 'En livraison',
      key: 'en_livraison',
      cls: 'badge-en_livraison',
      icon: '<svg class="icon icon-status icon-truck-drive" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="1" y="3" width="14" height="13" rx="1.5"/><polygon points="15 8 19 8 22 11 22 16 15 16 15 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="17.5" cy="18.5" r="2.5"/></svg>'
    },
    livree: {
      label: 'Livrée',
      key: 'livree',
      cls: 'badge-livree',
      icon: '<svg class="icon icon-status icon-check-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>'
    }
  };

  return {
    open: open, load: load, state: state, save: save, remove: remove, reset: reset,
    getDoc: getDoc, client: client, order: order, article: article,
    clientOrders: clientOrders, orderPayments: orderPayments, clientPayments: clientPayments,
    versementsOf: versementsOf,
    directPaidOf: directPaidOf, orderAllocatedVersement: orderAllocatedVersement,
    orderAllocatedVersementsList: orderAllocatedVersementsList,
    paidOf: paidOf, remainingOf: remainingOf, clientRemaining: clientRemaining,
    globalRemaining: globalRemaining,
    orderDoc: orderDoc, nextOrderNumber: nextOrderNumber, nextClientCode: nextClientCode,
    STATUS: STATUS
  };
})();
