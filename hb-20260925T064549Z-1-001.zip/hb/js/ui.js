/* Composants d'interface mobile : toast, bottom sheet, confirmation, visionneuse */
window.UI = (function () {
  var sheetRoot = function () { return document.getElementById('sheet-root'); };

  function toast(msg) {
    var root = document.getElementById('toast-root');
    var el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    root.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .25s';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 250);
    }, 2200);
  }

  function closeSheet() {
    var root = sheetRoot();
    root.innerHTML = '';
    document.body.style.overflow = '';
  }

  /* opts: {title, body(html), onMount(el, close)} */
  function sheet(opts) {
    var root = sheetRoot();
    root.innerHTML = '';
    var overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML =
      '<div class="sheet" role="dialog"><div class="handle"></div>' +
      (opts.title ? '<h2>' + U.esc(opts.title) + '</h2>' : '') +
      '<div class="sheet-body"></div></div>';
    var box = overlay.querySelector('.sheet-body');
    if (typeof opts.body === 'string') box.innerHTML = opts.body;
    else if (opts.body) box.appendChild(opts.body);
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeSheet();
    });
    root.appendChild(overlay);
    document.body.style.overflow = 'hidden';
    if (opts.onMount) opts.onMount(box, closeSheet);
    return closeSheet;
  }

  function confirm(opts) {
    return new Promise(function (resolve) {
      sheet({
        title: opts.title,
        body:
          '<p class="sub" style="margin-bottom:18px">' + U.esc(opts.text || '') + '</p>' +
          '<button class="btn danger" data-ok>' + U.esc(opts.okLabel || 'Supprimer') + '</button>' +
          '<div style="height:10px"></div>' +
          '<button class="btn ghost" data-cancel>Annuler</button>',
        onMount: function (el, close) {
          el.querySelector('[data-ok]').onclick = function () { close(); resolve(true); };
          el.querySelector('[data-cancel]').onclick = function () { close(); resolve(false); };
        }
      });
    });
  }

  function viewDocument(docId) {
    Store.getDoc(docId).then(function (doc) {
      if (!doc) return toast('Document introuvable');
      var v = document.createElement('div');
      v.className = 'viewer';
      var content = doc.fileType === 'application/pdf'
        ? '<iframe src="' + doc.data + '"></iframe>'
        : '<img src="' + doc.data + '" alt="' + U.esc(doc.fileName) + '" />';
      v.innerHTML =
        '<div class="vhead"><button data-close>' + I.back + ' Fermer</button><div class="spacer"></div>' +
        '<a class="btn sm soft" style="text-decoration:none" download="' + U.esc(doc.fileName) + '" href="' + doc.data + '">Télécharger</a></div>' +
        '<div class="vbody">' + content + '</div>';
      v.querySelector('[data-close]').onclick = function () { v.remove(); };
      document.body.appendChild(v);
    });
  }

  function emptyState(icon, title, text, btnLabel, onClick) {
    var d = document.createElement('div');
    d.className = 'empty';
    d.innerHTML = '<div class="ic">' + icon + '</div><h3>' + U.esc(title) + '</h3><p>' + U.esc(text) + '</p>' +
      (btnLabel ? '<button class="btn" data-act>' + U.esc(btnLabel) + '</button>' : '');
    if (btnLabel && onClick) d.querySelector('[data-act]').onclick = onClick;
    return d;
  }

  function statusBadge(status) {
    var s = Store.STATUS[status] || Store.STATUS.a_livrer;
    var iconHtml = s.icon || s.dot || '';
    return '<span class="badge status-badge ' + (s.cls || '') + '">' +
      '<span class="badge-icon-wrap">' +
        '<span class="badge-beacon"></span>' +
        iconHtml +
      '</span>' +
      '<span class="badge-text">' + s.label + '</span>' +
    '</span>';
  }

  function topbar(title, backHash) {
    return '<div class="topbar"><button class="back" data-back>' + I.back + '</button><div class="title">' + U.esc(title) + '</div></div>';
  }

  function bindBack(root) {
    var b = root.querySelector('[data-back]');
    if (b) b.onclick = function () { history.back(); };
  }

  return {
    toast: toast, sheet: sheet, closeSheet: closeSheet, confirm: confirm,
    viewDocument: viewDocument, emptyState: emptyState, statusBadge: statusBadge,
    topbar: topbar, bindBack: bindBack
  };
})();
