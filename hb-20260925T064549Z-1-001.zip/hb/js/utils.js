/* Utilitaires généraux */
window.U = (function () {
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function formatCurrency(n) {
    var v = Math.round(Number(n) || 0);
    var neg = v < 0;
    v = Math.abs(v);
    var s = String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    return (neg ? '-' : '') + s + ' DA';
  }

  function formatNumber(n) {
    return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }

  function todayISO() {
    var d = new Date();
    return d.toISOString().slice(0, 10);
  }

  function formatDate(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    var p = function (x) { return x < 10 ? '0' + x : '' + x; };
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear();
  }

  var MOIS = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
  function formatDateLong(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    return d.getDate() + ' ' + MOIS[d.getMonth()] + ' ' + d.getFullYear();
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function initials(name) {
    var n = (name || '?').trim();
    return n.charAt(0).toUpperCase();
  }

  function norm(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

  function match(haystacks, q) {
    var query = norm(q).trim();
    if (!query) return true;
    var all = haystacks.map(norm).join(' ');
    return query.split(/\s+/).every(function (t) { return all.indexOf(t) !== -1; });
  }

  /* Compression d'image : lisible mais légère */
  function compressImage(file, maxDim, quality) {
    maxDim = maxDim || 1600;
    quality = quality || 0.82;
    return new Promise(function (resolve, reject) {
      if (!file) return reject(new Error('Aucun fichier'));
      if (file.type === 'application/pdf' || file.type.indexOf('image/') !== 0) {
        var fr = new FileReader();
        fr.onload = function () { resolve({ data: fr.result, type: file.type, name: file.name, size: file.size }); };
        fr.onerror = function () { reject(new Error('Lecture impossible')); };
        return fr.readAsDataURL(file);
      }
      var reader = new FileReader();
      reader.onload = function () {
        var img = new Image();
        img.onload = function () {
          var w = img.naturalWidth, h = img.naturalHeight;
          var scale = Math.min(1, maxDim / Math.max(w, h));
          var cw = Math.round(w * scale), ch = Math.round(h * scale);
          var c = document.createElement('canvas');
          c.width = cw; c.height = ch;
          var ctx = c.getContext('2d');
          ctx.fillStyle = '#fff';
          ctx.fillRect(0, 0, cw, ch);
          ctx.drawImage(img, 0, 0, cw, ch);
          var data = c.toDataURL('image/jpeg', quality);
          resolve({
            data: data,
            type: 'image/jpeg',
            name: (file.name || 'photo').replace(/\.[^.]+$/, '') + '.jpg',
            size: Math.round(data.length * 0.75)
          });
        };
        img.onerror = function () { reject(new Error('Image invalide')); };
        img.src = reader.result;
      };
      reader.onerror = function () { reject(new Error('Lecture impossible')); };
      reader.readAsDataURL(file);
    });
  }

  return {
    uid: uid, formatCurrency: formatCurrency, formatNumber: formatNumber,
    todayISO: todayISO, formatDate: formatDate, formatDateLong: formatDateLong,
    esc: esc, initials: initials, match: match, norm: norm, compressImage: compressImage
  };
})();
